# Kenjal Khadka — Engineering Portfolio

This is the source for the GitHub Pages portfolio at `https://kenjalkhadka.github.io/`.

## Folder structure

```text
Kenjalkhadka.github.io/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── main.js
└── projects/
    ├── twin-turbo-v6.html
    ├── combustion-chamber.html
    └── rocketry.html
```

## Publish on GitHub Pages

1. Extract this ZIP file on your computer.
2. Open the repository `Kenjalkhadka/kenjalkhadka.github.io`.
3. Choose **Add file → Upload files**.
4. Upload the contents of the extracted folder, preserving the folder structure.
5. Commit directly to the `main` branch.
6. Wait a few minutes, then refresh `https://kenjalkhadka.github.io/`.

When GitHub asks whether to replace `index.html`, choose the option that updates the existing file.

## Before sharing publicly

- Add a professional email and LinkedIn URL if you want them displayed.
- Add approved project images and drawings.
- Confirm that team project information is approved for public sharing.
- Update project status and descriptions as the work progresses.
