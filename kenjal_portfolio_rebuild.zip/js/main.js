const menuToggle = document.getElementById("menu-toggle");
const sidebar = document.getElementById("sidebar");

if (menuToggle && sidebar) {
  menuToggle.addEventListener("click", () => {
    const isOpen = sidebar.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  });

  sidebar.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      sidebar.classList.remove("open");
      menuToggle.setAttribute("aria-expanded", "false");
    });
  });
}

const searchInput = document.getElementById("site-search");
const searchResults = document.getElementById("search-results");

const searchableSections = [
  { title: "Overview", href: "#overview", terms: "home introduction portfolio" },
  { title: "About me", href: "#about", terms: "nepal university cincinnati mechanical engineering" },
  { title: "Why mechanical engineering?", href: "#why-engineering", terms: "automobiles engines aerospace curiosity creativity" },
  { title: "What I do", href: "#what-i-do", terms: "design model analyze document build learn" },
  { title: "Twin Turbo V6 Engine Design", href: "projects/twin-turbo-v6.html", terms: "siemens nx cad engine assembly" },
  { title: "Combustion Chamber Project", href: "projects/combustion-chamber.html", terms: "propulsion regenerative cooling heat transfer structural analysis" },
  { title: "Level 1 Rocket Construction", href: "projects/rocketry.html", terms: "rocketry openrocket structures fabrication" },
  { title: "Team experience", href: "#experience", terms: "rocketry engineers without borders aerospace society" },
  { title: "Technical skills", href: "#skills", terms: "solidworks onshape autocad python matlab labview" },
  { title: "Professional development", href: "#development", terms: "laser cutting 3d scanning systems engineering" },
  { title: "Contact", href: "#contact", terms: "github connect" }
];

if (searchInput && searchResults) {
  searchInput.addEventListener("input", () => {
    const query = searchInput.value.trim().toLowerCase();
    searchResults.innerHTML = "";
    if (!query) {
      searchResults.hidden = true;
      return;
    }
    const matches = searchableSections.filter((item) =>
      (item.title + " " + item.terms).toLowerCase().includes(query)
    );
    matches.forEach((item) => {
      const link = document.createElement("a");
      link.href = item.href;
      link.textContent = item.title;
      searchResults.appendChild(link);
    });
    if (matches.length === 0) {
      const empty = document.createElement("a");
      empty.textContent = "No matching section found";
      empty.href = "#";
      empty.addEventListener("click", (event) => event.preventDefault());
      searchResults.appendChild(empty);
    }
    searchResults.hidden = false;
  });

  document.addEventListener("click", (event) => {
    if (!searchResults.contains(event.target) && !searchInput.contains(event.target)) {
      searchResults.hidden = true;
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "/" && document.activeElement !== searchInput) {
      event.preventDefault();
      searchInput.focus();
    }
    if (event.key === "Escape") {
      searchResults.hidden = true;
      searchInput.blur();
    }
  });
}
